package com.cdg.app.cbrowxr

import android.app.Application
import com.cdg.app.cbrowxr.browser.BrowserEngine
import com.cdg.app.cbrowxr.caster.LocalStreamProxy
import com.cdg.app.cbrowxr.updater.EngineUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CBrowxrApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    lateinit var streamProxy: LocalStreamProxy
        private set

    override fun onCreate() {
        super.onCreate()
        BrowserEngine.initRuntime(this)
        streamProxy = LocalStreamProxy(8899)
        try {
            streamProxy.start()
        } catch (_: Exception) {
        }
        appScope.launch {
            EngineUpdater.initializeEngines(this@CBrowxrApp)
        }
    }

    override fun onTerminate() {
        streamProxy.stop()
        super.onTerminate()
    }
}
